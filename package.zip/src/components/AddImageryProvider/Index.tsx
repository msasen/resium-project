import { ArcGisMapServerImageryProvider } from "cesium";
import { Viewer, ImageryLayer } from "resium";

import { IFrame } from "@/interfaces/Opacity";

const AddImageryProvider = (props: IFrame) => {
  const { frame, url } = props;
  const { opacity, visibility } = frame;
  return (
    <div>
      {visibility ? null : (
        <ImageryLayer
          imageryProvider={
            new ArcGisMapServerImageryProvider({
              url: url,
            })
          }
          alpha={opacity}
        />
      )}
    </div>
  );
};

export default AddImageryProvider;
